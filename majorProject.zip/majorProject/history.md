# Achievments / Milestones

## 10/12/2018
  - Created proposal
## 11-13/12/2018
  - Was away or working/helping Tyndall with our pair programming assignment
## 7-16/01/2019
  - Worked and created all classes for the game and basic knowledge for it
## 17/01/2019
  - Had collision detection working in console
## 20/01/2019
  - Added Random Generating for the slime
## 22/01/2019
  - Finished assignment 2 hours late with every state function and images working
